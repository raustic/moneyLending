import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity('Borrowers')
export class Borrower{
@PrimaryGeneratedColumn()
Id:number
@Column()
firstName:string
@Column()
lastName:string
@Column()    
contactNumber:number 
@Column()
watsAppNumber:string
@Column()
addressLine1:string
@Column()
addressLine2:string
@Column()
zip:string
@Column()
states:string
@Column()
CreatedOn:Date

}