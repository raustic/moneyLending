export interface UserDTO{
    Id:number
    UserType:number
    firstName:string
    lastName:string
    mobile:string
    email:string
    address1:string
    address2:string
    state:string
    zip:string
    states:string  
    password:string
}