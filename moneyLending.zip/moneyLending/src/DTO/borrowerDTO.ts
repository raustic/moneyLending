export interface BorrowerDTO{
    
Id:number

firstName:string
lastName:string
contactNumber:number 
watsAppNumber:string
addressLine1:string
addressLine2:string
zip:string
states:string
}