import { Test, TestingModule } from '@nestjs/testing';
import { TreasurerService } from './treasurer.service';

describe('TreasurerService', () => {
  let service: TreasurerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TreasurerService],
    }).compile();

    service = module.get<TreasurerService>(TreasurerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
