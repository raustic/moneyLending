import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity('RoleType')
export class Types{
    Id:number
    @Column()
    RoleName:string
    @Column()
    createdOn:Date
    @Column()
    IsActive:boolean
}