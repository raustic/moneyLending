import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity('Lenders')
export class Lender{
 @PrimaryGeneratedColumn()   
Id:number
@Column()
firstName:string
@Column()
lastName:string
@Column()
mobileNumber:string
@Column()
address1:string
@Column()
address2:string
@Column()
zip:string
@Column()
states:string
@Column()
lendingAmount:number
@Column()
lendingOn:Date
}