import { Controller, Get, HttpStatus } from '@nestjs/common';
import { AdminService } from './admin.service';

@Controller('admin')
export class AdminController {
    constructor(private _adminService:AdminService){}
    @Get()
    async getAllCustomers()
    {
        const users=this._adminService.showAllCustomers();
        return{
            statusCode:HttpStatus.OK,
            message:'Customer Fetched Successfully',
            users
        };
    }
    
}
