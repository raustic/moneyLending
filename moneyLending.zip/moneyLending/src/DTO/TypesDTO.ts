export interface TypesDTO{
    Id:number
    RoleName:string
    IsActive:boolean
}