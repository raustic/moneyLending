import { Module } from '@nestjs/common';
import { CustomerService } from './customer/customer.service';

@Module({
  providers: [CustomerService]
})
export class CustomerModule {}
