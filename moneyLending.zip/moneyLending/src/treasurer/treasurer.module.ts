import { Module } from '@nestjs/common';
import { TreasurerService } from './treasurer/treasurer.service';

@Module({
  providers: [TreasurerService]
})
export class TreasurerModule {}
