import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity('Transactions')
export class Transactions{
@PrimaryGeneratedColumn()
Id:number
@Column()
borrowerId:number
@Column()    
borrowAmount:number
@Column()
borrowOn:Date
@Column()
paidMode:string
@Column()    
createdOn:Date

}