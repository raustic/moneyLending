import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { identity } from 'rxjs';
import { UserDTO } from 'src/DTO/UserDTO';
import { Borrower } from 'src/entity/borrower';
import { Lender } from 'src/entity/Lender';
import {Transactions } from 'src/entity/tranasaction';
import { Types } from 'src/entity/type';
import { User } from 'src/entity/User';
import { Repository } from 'typeorm';

@Injectable()
export class AdminService {
    constructor(
        @InjectRepository(Borrower) private _userRepo:Repository<User>){}
        // @InjectRepository(Types)private _typesRepo:Repository<Types>,
        // @InjectRepository(Lender)private _lendersRepo:Repository<Lender>,
        // @InjectRepository(Borrower)private _borrowerRepo:Repository<Borrower>,
        // @InjectRepository(Transactions)private _transRepo:Repository<Transactions>){}

        async showAllCustomers()
        {
            return await this._userRepo.find();
        }
        async CreateCustomer(data:UserDTO)
        {
            const user=this._userRepo.create(data);
            await this._userRepo.save(data);
            return user;
        }
        async FindCusttomerByMobile(mobile:string):Promise<UserDTO>
        {
            return await this._userRepo.findOne({
                where:{
                    mobile:mobile
                }
            });
        }
        async GetUserById(id:number)
        {
            return await this._userRepo.findOne({
                where:{Id:id}
            });
        }
        async UpdateUser(id:number,data:Partial<UserDTO>)
        {
            await this._userRepo.update({Id:id},data);
            return await this._userRepo.findOne({Id:id});
        }
        async DeleteUser(id:number){
            await this._userRepo.delete({Id:id});
            return {deleted:true};
        }
}
