import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AdminModule } from './admin/admin.module';
import { CollectorModule } from './collector/collector.module';
import { TreasurerModule } from './treasurer/treasurer.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomerModule } from './customer/customer.module';

@Module({
  imports: [TypeOrmModule.forRoot(),AdminModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
