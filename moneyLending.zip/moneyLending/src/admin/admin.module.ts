import { Module } from '@nestjs/common';
import { AdminService } from './admin/admin.service';
import { AdminController } from './admin/admin.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/entity/User';
import { Types } from 'src/entity/type';
import { Lender } from 'src/entity/Lender';
import { Borrower } from 'src/entity/borrower';
import { Transactions } from 'src/entity/tranasaction';

@Module({
  imports:[TypeOrmModule.forFeature([Borrower])],
  providers: [AdminService],
  controllers: [AdminController]
})
export class AdminModule {}
