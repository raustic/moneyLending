export interface LenderDTO{
    Id:number
    firstName:string
    lastName:string
    mobileNumber:string
    address1:string
    address2:string
    zip:string
    states:string
    lendingAmount:number
    lendingOn:Date
    
}