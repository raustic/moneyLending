import { Type } from "@nestjs/common";
import { BeforeInsert, Column, Entity, PrimaryGeneratedColumn } from "typeorm";
import * as crypto from 'crypto';
@Entity('Users')
export class User{
    @PrimaryGeneratedColumn()
    Id:number
    @Column()
    UserType:number
    @Column()
    firstName:string
    @Column()
    lastName:string
    @Column()
    mobile:string
    @Column()
    email:string
    @Column()
    address1:string
    @Column()
    address2:string
    @Column()
    state:string
    @Column()
    zip:string
    @Column()
    states:string  
    @BeforeInsert()
    hashPassword(){
        this.password=crypto.createHmac('sha256',this.password).digest('hex');
    } 
    password:string
    @Column()
    CreatedOn:Date

}