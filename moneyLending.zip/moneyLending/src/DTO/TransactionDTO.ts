export interface TransactionDTO{
Id:number
borrowerId:number
borrowAmount:number
borrowOn:Date
paidMode:string
}